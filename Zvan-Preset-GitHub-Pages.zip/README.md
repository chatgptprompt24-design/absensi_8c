# Zvan Preset — 100 Alight Motion

Static website katalog 100 preset Alight Motion.

## Deploy ke GitHub Pages
1. Upload seluruh isi folder ini ke repository GitHub.
2. Buka **Settings → Pages**.
3. Pada **Build and deployment**, pilih **Deploy from a branch**.
4. Branch: `main`, folder: `/ (root)`.
5. Simpan dan tunggu GitHub Pages selesai.

Website tidak membutuhkan Node.js, database, atau server.
